/*
 * Copyright (c) 2019. PAGE and Sons
 */
package live.page.web.utils;

import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.UnwindOptions;
import live.page.web.db.Aggregator;
import live.page.web.db.Db;
import live.page.web.db.Pipeliner;
import live.page.web.utils.json.Json;
import org.bson.BsonUndefined;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class LinkerAggregator {
	public static List<Bson> getPipeline(String text, Aggregator grouper) {

		List<Bson> pipeline = new ArrayList<>();

		pipeline.add(Aggregates.project(grouper.getProjection().put("links", new ArrayList<>())));
		Map<String, Class<? extends Pipeliner>> pipeliner = ObjsUtils.getSearchers();

		for (String parent : Settings.VALID_PARENTS) {

			if (pipeliner.containsKey(parent.toLowerCase())) {
				pipeline.add(Aggregates.project(grouper.getProjection().put("links" + parent, new Json("$slice", Arrays.asList(new Json("$split", Arrays.asList("$" + text, parent + "(")), 1, 100)))));


				pipeline.add(Aggregates.unwind("$links" + parent, new UnwindOptions().preserveNullAndEmptyArrays(true)));
				pipeline.add(Aggregates.project(grouper.getProjection().put("links" + parent, new Json("$substrCP", Arrays.asList("$links" + parent, 0, Db.DB_KEY_LENGTH)))));

				pipeline.add(Aggregates.group("$_id", grouper.getGrouper(Accumulators.push("links" + parent, "$links" + parent))));

				pipeline.add(Aggregates.project(grouper.getProjection()
						.put("links" + parent, new Json("$map", new Json("input", "$links" + parent).put("as", "ele").put("in", new Json("$arrayElemAt", Arrays.asList(new Json("$split", Arrays.asList("$$ele", ")")), 0)))))
				));

				pipeline.add(Aggregates.project(grouper.getProjection()
						.put("links" + parent, new Json("$filter", new Json("input", "$links" + parent).put("as", "ele").put("cond", new Json("$eq", Arrays.asList(new Json("$strLenCP", "$$ele"), Db.DB_KEY_LENGTH)))))
				));

				pipeline.add(Aggregates.unwind("$links" + parent, new UnwindOptions().preserveNullAndEmptyArrays(true).includeArrayIndex("links_order")));
				//links
				pipeline.add(Aggregates.lookup(parent, "links" + parent, "_id", "links" + parent));

				pipeline.add(Aggregates.unwind("$links" + parent, new UnwindOptions().preserveNullAndEmptyArrays(true)));

				pipeline.addAll(ObjsUtils.getConstructor(parent.toLowerCase()).getUrlizifier(grouper.clone()
						.addKey("links_order").addKey("links" + parent), "links" + parent));

				pipeline.add(Aggregates.project(grouper.getProjection()
						.put("links_order", true)
						.put("links" + parent,
								new Json()
										.put("id", "$links" + parent + "._id")
										.put("top_title", "$links" + parent + ".top_title")
										.put("title", "$links" + parent + ".title")
										.put("url", "$links" + parent + ".url")
										.put("domain", "$links" + parent + ".domain")
										.put("tag", new Json("$concat", Arrays.asList(parent + "(", "$links" + parent + "._id", ")")))
										.put("logo", "$links.logo")
						)
				));


				pipeline.add(new Json("$sort", new Json("links_order", 1)));
				pipeline.add(Aggregates.group("$_id", grouper.getGrouper(Accumulators.push("links" + parent, "$links" + parent))));


				pipeline.add(Aggregates.project(grouper.getProjection()
						.put("links" + parent,
								new Json("$filter", new Json("input", "$links" + parent).put("as", "ele").put("cond", new Json("$ne", Arrays.asList("$$ele.id", new BsonUndefined()))))
						)
				));


				pipeline.add(Aggregates.project(grouper.getProjection().put("links_", new Json("$concatArrays", Arrays.asList("$links", "$links" + parent)))));
				pipeline.add(Aggregates.project(grouper.getProjection().put("links", "$links_")));

			}
		}


		return pipeline;
	}
}
